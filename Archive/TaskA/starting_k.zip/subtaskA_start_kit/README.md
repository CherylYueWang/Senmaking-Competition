# How to submit

Welcome to use the starting kit for Commonsense Validation and Explanation Subtask A!

The sample data, sample submittion file format as well as the evaluation script are all included here! You can explore the sample data, write the answers as the format of `sample_result_submission`, and then zip the result folder and submit!

If you need any help, feel free to post at https://groups.google.com/d/forum/semeval-2020-task-4-all.  
